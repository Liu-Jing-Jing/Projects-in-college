package com.tarena.typewriter;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * ������Ϸ������
 * @author Kevin
 *
 */
public class WriterPanel extends JPanel{
	BufferedImage back;//����ͼ
	
	WriterPanel() throws IOException{//������
		back = ImageIO.read(getClass().
				   getResource("/images/bg.jpg"));
	}
	
	@Override
	public void paint(Graphics g) {
		g.drawImage(back,0,0,this);
	}
	
	public static void main(String[] args) throws IOException {
		JFrame frame = new JFrame("������Ϸ");
		WriterPanel panel = new WriterPanel();
		
		frame.add(panel);
		frame.setSize(1000, 700);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(
				               JFrame.EXIT_ON_CLOSE);
		
	}
}









